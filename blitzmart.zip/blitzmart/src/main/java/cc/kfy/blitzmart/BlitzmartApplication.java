package cc.kfy.blitzmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlitzmartApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlitzmartApplication.class, args);
	}

}
